

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	
<!-- http://localhost/databaseConnectivityCakePhp/index.php/articles-->
<table border="1" cellpadding="6" cellspacing="0">
	<tr>
		<th>ID</th>
		<th>Title</th>
		<th>Body</th>
	</tr>
	<?php foreach ($articles as $a): ?>
	<tr>
		<td><?php echo h($a['Article']['id']); ?></td>
		<td><?php echo h($a['Article']['title']); ?></td>
		<td><?php echo h($a['Article']['body']); ?></td>
	</tr>
	<?php endforeach; ?>
</table>
</body>
</html>


<h1>Articles</h1>


