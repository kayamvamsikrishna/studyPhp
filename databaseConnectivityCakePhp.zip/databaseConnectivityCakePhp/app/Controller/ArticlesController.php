<?php
App::uses('AppController', 'Controller');

class ArticlesController extends AppController {

	public function index() {
		//  load the table (model)
		$this->loadModel('Article');
		//  get all rows from the articles table
		$articles = $this->Article->find('all');
		$this->set('articles', $articles);
	}
}
