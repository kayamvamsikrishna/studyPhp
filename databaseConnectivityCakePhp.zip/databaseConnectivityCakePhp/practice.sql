CREATE DATABASE IF NOT EXISTS practice;
USE practice;

CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    body TEXT
);

INSERT INTO articles (title, body) VALUES
('Hello CakePHP', 'My first article'),
('Second post', 'Connected to the practice database');
